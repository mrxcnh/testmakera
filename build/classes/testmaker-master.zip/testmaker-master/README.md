Test Maker

Một vài note cho An và Quang:

  - Các file câu hỏi tôi lưu dưới định dạng như sau:
    + Tên file: Tự luận: essay + Tênmonhoc.dat . Eg: essayIT4040.dat. Trắc nghiệm: multiple + tenmonhoc.dat. Eg: multipleIT4040.dat
    + Ghi dữ liệu theo kiểu nhị phân, ghi cả một object ra file.
    + Cách ghi ra file có thể tham khảo trong các hàm: writeListSubject, writeListEssay, writeListMultipleChoice.
    + Cách đọc dữ liệu tham khảo trong hàm: readListSubject.
    
  - 2 ông dựa vào đó để code một cái Frame mới để thêm đề thi nhé. Có gì thì comment trên Facebook trao đổi luôn. 
